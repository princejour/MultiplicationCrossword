package com.walhero.multicross;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int size = 7;
    private EditText[][] cells = new EditText[size][size];
    private Character[][] answers = new Character[size][size];
    private final List<Clue> clues = new ArrayList<>();
    private TextView resultText;
    private int level = 1;

    private final int bgColor = Color.rgb(244, 248, 245);
    private final int cardColor = Color.WHITE;
    private final int primary = Color.rgb(46, 125, 50);
    private final int primaryDark = Color.rgb(27, 94, 32);
    private final int emptyCell = Color.rgb(38, 50, 56);
    private final int inputCell = Color.WHITE;
    private final int correctColor = Color.rgb(200, 230, 201);
    private final int wrongColor = Color.rgb(255, 205, 210);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(232, 245, 233));
        buildPuzzle();
        buildUi();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(18));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("كلمات جدول الضرب");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(primaryDark);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("املأ الأرقام حسب عمليات الضرب. كل خانة تأخذ رقمًا واحدًا فقط.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(69, 90, 100));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(6), 0, dp(14));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(size);
        grid.setRowCount(size);
        grid.setPadding(dp(6), dp(6), dp(6), dp(6));
        grid.setBackgroundColor(cardColor);
        root.addView(grid, new LinearLayout.LayoutParams(-1, -2));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int cellSize = (screenWidth - dp(52)) / size;

        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                EditText cell = new EditText(this);
                cell.setGravity(Gravity.CENTER);
                cell.setTextSize(20);
                cell.setTypeface(Typeface.DEFAULT_BOLD);
                cell.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1)});
                cell.setInputType(InputType.TYPE_CLASS_NUMBER);
                cell.setSingleLine(true);
                cell.setPadding(0, 0, 0, 0);
                cell.setTextColor(Color.rgb(20, 20, 20));
                cell.setBackgroundColor(answers[r][c] == null ? emptyCell : inputCell);
                cell.setEnabled(answers[r][c] != null);
                cell.setSelectAllOnFocus(true);
                cells[r][c] = cell;

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = cellSize;
                params.height = cellSize;
                params.setMargins(dp(2), dp(2), dp(2), dp(2));
                grid.addView(cell, params);
            }
        }

        TextView clueTitle = new TextView(this);
        clueTitle.setText("التعليمات");
        clueTitle.setTextSize(22);
        clueTitle.setTypeface(Typeface.DEFAULT_BOLD);
        clueTitle.setTextColor(primaryDark);
        clueTitle.setPadding(0, dp(18), 0, dp(8));
        root.addView(clueTitle);

        LinearLayout cluesBox = new LinearLayout(this);
        cluesBox.setOrientation(LinearLayout.VERTICAL);
        cluesBox.setBackgroundColor(cardColor);
        cluesBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(cluesBox, new LinearLayout.LayoutParams(-1, -2));

        for (Clue clue : clues) {
            TextView t = new TextView(this);
            t.setText(clue.label + "  " + clue.text);
            t.setTextSize(17);
            t.setTextColor(Color.rgb(38, 50, 56));
            t.setPadding(0, dp(4), 0, dp(4));
            cluesBox.addView(t);
        }

        Button checkButton = new Button(this);
        checkButton.setText("تصحيح الإجابات");
        checkButton.setTextSize(18);
        checkButton.setTextColor(Color.WHITE);
        checkButton.setBackgroundColor(primary);
        checkButton.setAllCaps(false);
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(-1, dp(52));
        checkParams.setMargins(0, dp(16), 0, dp(8));
        root.addView(checkButton, checkParams);
        checkButton.setOnClickListener(v -> checkAnswers());

        Button newButton = new Button(this);
        newButton.setText("شبكة جديدة");
        newButton.setTextSize(17);
        newButton.setTextColor(primaryDark);
        newButton.setAllCaps(false);
        root.addView(newButton, new LinearLayout.LayoutParams(-1, dp(50)));
        newButton.setOnClickListener(v -> {
            level = level % 3 + 1;
            buildPuzzle();
            buildUi();
        });

        resultText = new TextView(this);
        resultText.setText("المستوى: " + level);
        resultText.setTextSize(18);
        resultText.setTypeface(Typeface.DEFAULT_BOLD);
        resultText.setTextColor(primaryDark);
        resultText.setGravity(Gravity.CENTER);
        resultText.setPadding(0, dp(12), 0, 0);
        root.addView(resultText, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scrollView);
    }

    private void buildPuzzle() {
        answers = new Character[size][size];
        clues.clear();

        if (level == 1) {
            addWord("أفقي 1:", "3 × 4 = ؟", 0, 0, true, "12");
            addWord("عمودي 1:", "4 × 6 = ؟", 0, 1, false, "24");
            addWord("أفقي 2:", "5 × 7 = ؟", 2, 0, true, "35");
            addWord("عمودي 2:", "6 × 6 = ؟", 2, 0, false, "36");
            addWord("أفقي 3:", "6 × 8 = ؟", 4, 3, true, "48");
            addWord("عمودي 3:", "6 × 7 = ؟", 4, 3, false, "42");
            addWord("أفقي 4:", "9 × 9 = ؟", 6, 4, true, "81");
        } else if (level == 2) {
            addWord("أفقي 1:", "7 × 8 = ؟", 0, 0, true, "56");
            addWord("عمودي 1:", "5 × 5 = ؟", 0, 0, false, "25");
            addWord("أفقي 2:", "9 × 6 = ؟", 2, 2, true, "54");
            addWord("عمودي 2:", "4 × 8 = ؟", 1, 3, false, "32");
            addWord("أفقي 3:", "8 × 8 = ؟", 4, 1, true, "64");
            addWord("عمودي 3:", "9 × 7 = ؟", 4, 1, false, "63");
            addWord("أفقي 4:", "7 × 7 = ؟", 6, 5, true, "49");
        } else {
            addWord("أفقي 1:", "8 × 9 = ؟", 0, 2, true, "72");
            addWord("عمودي 1:", "9 × 8 = ؟", 0, 2, false, "72");
            addWord("أفقي 2:", "6 × 9 = ؟", 2, 0, true, "54");
            addWord("عمودي 2:", "5 × 9 = ؟", 2, 0, false, "45");
            addWord("أفقي 3:", "8 × 7 = ؟", 4, 3, true, "56");
            addWord("عمودي 3:", "7 × 8 = ؟", 4, 3, false, "56");
            addWord("أفقي 4:", "10 × 9 = ؟", 6, 4, true, "90");
        }
    }

    private void addWord(String label, String text, int row, int col, boolean horizontal, String answer) {
        clues.add(new Clue(label, text));
        for (int i = 0; i < answer.length(); i++) {
            int r = horizontal ? row : row + i;
            int c = horizontal ? col + i : col;
            answers[r][c] = answer.charAt(i);
        }
    }

    private void checkAnswers() {
        int total = 0;
        int correct = 0;
        boolean hasEmpty = false;

        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (answers[r][c] != null) {
                    total++;
                    String value = cells[r][c].getText().toString().trim();
                    if (value.length() == 0) {
                        hasEmpty = true;
                        cells[r][c].setBackgroundColor(Color.rgb(255, 249, 196));
                    } else if (value.charAt(0) == answers[r][c]) {
                        correct++;
                        cells[r][c].setBackgroundColor(correctColor);
                    } else {
                        cells[r][c].setBackgroundColor(wrongColor);
                    }
                }
            }
        }

        String message = "النتيجة: " + correct + " / " + total;
        if (correct == total) {
            message += "  ممتاز!";
            Toast.makeText(this, "أحسنت! كل الإجابات صحيحة", Toast.LENGTH_LONG).show();
        } else if (hasEmpty) {
            message += "  أكمل الخانات الصفراء.";
        } else {
            message += "  راجع الخانات الحمراء.";
        }
        resultText.setText(message);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class Clue {
        String label;
        String text;
        Clue(String label, String text) {
            this.label = label;
            this.text = text;
        }
    }
}
